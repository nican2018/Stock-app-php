<?php

if (isset($_SESSION['logged']) && $_SESSION['logged'] === true) {
    header('location: index.php?page=acceuil');
}
else {

    include(dirname(__FILE__) . '/../modeles/connexion.php');
    
    if (isset($_POST['conn'])) {
        if (!empty($_POST['username']) AND !empty($_POST['password'])) {
            $user = htmlSpecialChars($_POST['username']);
            $pass_user = htmlSpecialChars($_POST['password']);
            $pass = htmlSpecialChars(md5($pass_user));
            $retour = userControler::Connexion($user, $pass);
            if ($retour) {
                $_SESSION['logged'] = true;
                $_SESSION['dm_user'] = $user;
                $_SESSION['dm_pass'] = $pass;
                
                header('location: admin.php');
            }
            else {
                
                    $erreur = "*Utilisateur ou Mot de passe incorrect";
            }
        }
        else {
            $erreur = "*Veuillez remplir tous les champs";
        }
    }
}
