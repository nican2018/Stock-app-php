<?php
/**
 * Created by PhpStorm.
 * User: GRAD&MED
 * Date: 17/07/2017
 * Time: 19:07
 */
 
session_start();

if(!isset($_SESSION["id_user"])){
    $_SESSION["id_user"]=0;
}

function base()
{
    require (dirname(__FILE__).'/../modeles/ini/config.inc.php');
    try
    {
        $base =  new PDO("mysql:host=".$host.";dbname=".$bdd_name,$username,$password);
    }
    catch(Exception $e)
    {
        false;
    }

    return $base;
}

?>


