﻿<?php
 include(dirname(__FILE__) . '/../modeles/appro.php');
if (!isset($_SESSION['logged'])) {
    header('location: index.php?page=conn');
}
else {
     if (isset($_POST['bt_appro'])) {
        if (!empty($_POST['article']) AND !empty($_POST['qte'])) {
            $article = $_POST['article'];
            $qte = htmlSpecialChars($_POST['qte']);
   	    $date=date("d/m/Y");
            $retour = approControleur::Ajout($article, $qte, $date);
	    if ($retour) {
		 $critik=0;
		 $ret = approControleur::Stock($article, $critik, $qte);
		 if($ret){$msg="*Article ajouté avec succes!";}
            }
            else { 
                    $msg = "*Une erreur s'est produite, réessayez";
            }
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }
 
}

