﻿<?php
 include(dirname(__FILE__) . '/../modeles/appro.php');
if (!isset($_SESSION['logged'])) {
    header('location: index.php?page=conn');
}
else {
     if (isset($_POST['bt_appro'])) {
        if (!empty($_POST['article']) AND !empty($_POST['qte'])) {
            $article = $_POST['article'];
	    $unit = $_POST['unite'];
            $qte = htmlSpecialChars($_POST['qte']);
   	    $date=date("d/m/Y");
            $retour = approControleur::Ajout($article, $qte, $date,$unit);
	    if ($retour) {
		 $critik=0;
		 $ret = approControleur::Stock($article, $critik, $qte);
		 if($ret){$msg="*Article ajouté avec succes!";}
            }
            else { 
                    $msg = "*Une erreur s'est produite, réessayez";
            }
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }
if (isset($_POST['bt_update'])) {
        if (!empty($_POST['article']) AND !empty($_POST['critik'])) {
            $article = $_POST['article'];
            $critik = htmlSpecialChars($_POST['critik']);
   	    //$date=date("d/m/Y");
            $retour = approControleur::Update($article, $critik);
	    if ($retour) {
		 $r="*Point critique modifié!";
            }
            else { 
                    $r = "*Une erreur s'est produite, réessayez";
            }
            
        }
        else {
            $r = "*Veuillez remplir tous les champs";
        }
 }

 if (isset($_POST['bt_pwrd'])) {
        if (!empty($_POST['pswrd']) AND !empty($_POST['confirm'])) {
            $pswrd = $_POST['pswrd'];
            $confirm= htmlSpecialChars($_POST['confirm']);
	    $pass = htmlSpecialChars(md5($pswrd));
	    $id= $_SESSION['id_user'];
	    if($pswrd==$confirm){

		$retour = approControleur::PassUpdate($pass, $id);
		    if ($retour) {
		         $msg="*Mot de passe mis à jour!";
		    }
		    else { 
		            $msg = "*Une erreur s'est produite, réessayez";
		    }	
		}
	else{
		$msg ="*Les deux mots de passe ne sont pas identique!";
		}
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }

if (isset($_POST['bt_sort'])) {
        if (!empty($_POST['destin']) AND !empty($_POST['article']) AND !empty($_POST['qte'])) {
            $destin = $_POST['destin'];
	    $unit = $_POST['unite'];
	    $article = $_POST['article'];
            $qte = htmlSpecialChars($_POST['qte']);
   	    $date=date("d/m/Y");
	    $heure=date("H:i:s");
            $retour = approControleur::Sortie($destin, $article, $qte,$unit, $date, $heure);
	    if ($retour) {
                 $msg="*Sortie effectuée avec succes!";
            }
            else { 
                    $msg = "*Stock insuffisant, réessayez!";
            }
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }
if (isset($_POST['bt_new'])) {
        if (!empty($_POST['des']) AND !empty($_POST['critik'])) {
            $des= $_POST['des'];
	    $critik = $_POST['critik'];
	    $qte=0;
            $retour = approControleur::Stock($des, $critik,$qte);
	    if ($retour) {
                 $msg="*Article créé avec succès!";
            }
            else { 
                    $msg = "*Stock insuffisant, réessayez!";
            }
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }
if (isset($_POST['bt_sup'])) {
        if (!empty($_POST['admPwrd'])) {
            $admPwrd= $_POST['admPwrd'];
            $retour = approControleur::SuperAdmin($admPwrd);
	    if ($retour) {
                 $msg="*Article créé avec succès!";
            }
            else { 
                    $msg = "*Stock insuffisant, réessayez!";
            }
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }
if (isset($_POST['bt_modif'])) {
        if (!empty($_POST['art']) AND !empty($_POST['qte'])) {
            $id= $_POST['id_appro'];
	    $art= $_POST['art'];
	    $qte= $_POST['qte'];
            $retour = approControleur::SuperModif($id, $art, $qte);
	    if ($retour) {
                 $msg="*Article modifié avec succès!";
            }
            else { 
                    $msg = "*Une erreur s'est produite, réessayez!";
            }
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }
if (isset($_POST['bt_mdfSort'])) {
        if (!empty($_POST['art']) AND !empty($_POST['qte'])) {
            $id= $_POST['id_sorties'];
	    $art= $_POST['art'];
	    $qte= $_POST['qte'];
            $retour = approControleur::SuperModifSort($id, $art, $qte);
	    if ($retour) {
                 $msg="*Article modifié avec succès!";
            }
            else { 
                    $msg = "*Une erreur s'est produite, réessayez!";
            }
            
        }
        else {
            $msg = "*Veuillez remplir tous les champs";
        }
 }
 
 $reqSum = base()->prepare("SELECT * FROM user_tab");
 $reqSum->execute();
 $totalUser = $reqSum->rowCount();

 $reqSumClient = base()->prepare("SELECT * FROM  destin_tab");
 $reqSumClient->execute();
 $totalClient = $reqSumClient->rowCount();

$res1 = base()->prepare('SELECT sum(qte) AS totalQte FROM appro_tab');
$res1->execute();

$row1 = $res1->fetch(PDO::FETCH_ASSOC);
$totalQte=$row1["totalQte"];

$res2 = base()->prepare('SELECT sum(qte_sort) AS totalQteSort FROM sortie_tab');
$res2->execute();

$row2 = $res2->fetch(PDO::FETCH_ASSOC);
$totalQteSort=$row2["totalQteSort"];
 
}

