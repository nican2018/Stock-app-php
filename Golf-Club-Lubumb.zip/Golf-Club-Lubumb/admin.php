﻿<?php
$active="admin";
include('nav.php');
?>
 
<?php
 $dataPoints = array(); 	
?>
<?php
            $search2 = base()->prepare("SELECT desig, qte FROM stock"); 
			     $search2->execute();
			       
				while($res2 = $search2->fetch())
				{
			    array_push($dataPoints, array("label"=> $res2['desig'], "y"=> $res2['qte']));
				}
?>
<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="admin.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  </div>
<!--End-breadcrumbs-->

<!--Action boxes-->
  <div class="container-fluid">
    <div class="quick-actions_homepage">
      <ul class="quick-actions">
        <li class="bg_lb"> <a href="admin.php"> <i class="icon-dashboard"></i> Dashboard </a> </li>
         <li class="bg_ly"> <a href="rapport.php"> <i class="icon-inbox"></i> Rapports </a> </li>
        <li class="bg_lo"> <a href="appro.php"> <i class="icon-th"></i> Appro</a> </li>
        <li class="bg_ls"> <a href="sortie.php"> <i class="icon-fullscreen"></i> Sorties</a> </li>
	<li class="bg_lg"> <a href="calendar.php"> <i class="icon-calendar"></i> Calendrier</a> </li>
      </ul>
    </div>
<!--End-Action boxes-->    

<!--Chart-box-->    
    <div class="row-fluid">
      <div class="widget-box">
        <div class="widget-title bg_lg"><span class="icon"><i class="icon-signal"></i></span>
          <h5>Analyse</h5>
        </div>
        <div class="widget-content" >
          <div class="row-fluid">
            <div class="span9">
   		<div id="chartContainer"></div>
            </div>
            <div class="span3">
              <ul class="site-stats">
                <li class="bg_lh"><i class="icon-user"></i> <strong><?php echo $totalUser; ?></strong> <small>Total Users</small></li>
                <li class="bg_lh"><i class="icon-plus"></i> <strong></strong> <small>New Users </small></li>
                <li class="bg_lh"><i class="icon-tag"></i> <strong><?php echo $totalClient;?></strong> <small>Total Client</small></li>
                <li class="bg_lh"><i class="icon-tag"></i> <strong><?php echo round($totalQte);?></strong> <small>Total Appro</small></li>
                <li class="bg_lh"><i class="icon-repeat"></i> <strong><?php echo round($totalQteSort);?></strong> <small>Total sortie</small></li>
                <li class="bg_lh"><i class="icon-globe"></i> <strong>8540</strong> <small>Total Articles</small></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
<!--End-Chart-box--> 
    <hr/>
      </div>
    </div>
  </div>
</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2019 &copy;Nicanor Mayumu, Express Technology Lubumbashi</div>
</div>

<!--end-Footer-part-->

<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.dashboard.js"></script> 
<script src="js/jquery.gritter.min.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 
<script src="js/canvasjs.min.js"></script>

<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
  <script>
    window.onload = function () {
     
    var chart = new CanvasJS.Chart("chartContainer", {
    	animationEnabled: true,
    	theme: "dark1", // "light1", "light2", "dark1", "dark2"
    	title: {
    		text: "Etat du stock"
    	},
    	axisY: {
    		title: "Quantité",
    		includeZero: false
    	},
    	data: [{
    		type: "column",
    		dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
    	}]
    });
    chart.render();  
    }
    </script>
</body>
</html>
