<?php
include('modeles/connexion.php');
$user=htmlSpecialChars($_SESSION['dm_user']);
userControler::logoutUser($user);
header('location: index.php');
?>
