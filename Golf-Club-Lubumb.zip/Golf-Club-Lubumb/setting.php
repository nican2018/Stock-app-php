﻿<?php
$active="set";
include('nav.php');
?>
<!--main-container-part-->
<div id="content">
<!--breadcrumbs-->
  <div id="content-header">
    <div id="breadcrumb"> <a href="admin.php" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a><a href="setting.php?set=creer">Créer article</a><a href="setting.php?set=critik"  class="tip-bottom">Modifier point critique</a><a href="profile.php"  class="tip-bottom">Changer le mot de passe</a><a href="setting.php?set=unite"  class="tip-bottom"> Créer unité</a></div>
  </div>
<?php
if(isset($_GET['set'])){
$set=$_GET['set'];
switch($set){
	 
	case"critik":
?>
<div class="row-fluid center">
<div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Modifier point critique</h5>
        </div>
        <div class="widget-content nopadding">
          <form action="#" method="POST" class="form-horizontal">
           
 	   <div class="control-group">
              <label class="control-label">Désignation :</label>
              <div class="controls">
                 <?php $requette = base()->prepare("SELECT * FROM   stock");
        $requette->execute();
         
                echo'<select name="article">';
		while($res = $requette->fetch())
		{
		    echo '<option value="'.$res['desig'].'">'.$res['desig'].'</option>';
		}
                 
                echo'</select>';
         ?>
              </div>
            </div>
	    <div class="control-group">
              <label class="control-label">Point critique :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Point critique" name="critik"/>
              </div>
            </div>
	    <div class="controls">
		<span class="red-text"><b><?php
		 if(isset($r) AND !empty($r))
                                      {
                                               echo $r;
                                                   }
                                        ?>
                                                    </b>
                                                </span>
	        </div>
            <div class="form-actions ">
              <span class="pull-right"><button type="submit" class="btn btn-success" name="bt_update">Modifier</button></span>
            </div>
          </form>
        </div>
      </div>
</div>


<?php
	break;
	case"creer":
?>
<div class="row-fluid center">
       <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Nouveau article</h5>
        </div>

        <div class="widget-content nopadding">
          <form action="#" method="POST" class="form-horizontal">
           
 	   <div class="control-group">
              <label class="control-label">Désignation :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Désignation" name="des"/>
              </div>
            </div>
	    <div class="control-group">
              <label class="control-label">Point critique :</label>
              <div class="controls">
                <input type="text" class="span11" placeholder="Point critique" name="critik"/>
              </div>
            </div>
	    <div class="controls">
		<span class="red-text"><b><?php
		 if(isset($msg) AND !empty($msg))
                                      {
                                               echo $msg;
                                                   }
                                        ?>
                                                    </b>
                                                </span>
	        </div>
            <div class="form-actions ">
              <span class="pull-right"><button type="submit" class="btn btn-success" name="bt_new">Enregistrer</button></span>
            </div>
          </form>
        </div>
      </div>
</div>
<?php
break;
case"modifier":
if(isset($_GET['id_art'])) {
$idArt=$_GET['id_art']; 
  
        $req = base()->prepare("SELECT id_appro,Designation, qte FROM appro_tab WHERE  id_appro  = ?");
        $req->bindParam(1, $idArt,PDO::PARAM_INT);
        $req->execute();

        if($resultat = $req->fetch())
        {

?>
<div class="row-fluid center">
       <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Nouveau article</h5>
        </div>

        <div class="widget-content nopadding">
          <form action="#" method="POST" class="form-horizontal">
           
 	   <div class="control-group">
              <label class="control-label">Article :</label>
              <div class="controls">
		<input type="hidden" class="span11" value="<?php echo $resultat["id_appro"];?>" name="id_appro"/>
                <input type="text" class="span11" value="<?php echo $resultat["Designation"];?>" name="art"/>
              </div>
		
            </div>
	    <div class="control-group">
              <label class="control-label">Quantité :</label>
              <div class="controls">
                <input type="text" class="span11" value="<?php echo $resultat["qte"];?>" name="qte"/>
              </div>
		
            </div>
	    <div class="controls">
		<span class="red-text"><b><?php
		 if(isset($msg) AND !empty($msg))
                                      {
                                               echo $msg;
                                                   }
                                        ?>
                                                    </b>
                                                </span>
	        </div>
            <div class="form-actions ">
              <span class="pull-right"><button type="submit" class="btn btn-success" name="bt_modif">Valider</button></span>
            </div>
          </form>
        </div>
      </div>
</div>
<?php		
	}
	else{
		echo "Appro incorrect; veillez essayer";
	}
}

?>
<?php
break;
case"erreur":
if(isset($_GET['id_sort'])) {
$idArt=$_GET['id_sort']; 
  
        $req = base()->prepare("SELECT id_sort,destin_sort, article_sort, qte_sort  FROM sortie_tab WHERE  id_sort  = ?");
        $req->bindParam(1, $idArt,PDO::PARAM_INT);
        $req->execute();

        if($resultat = $req->fetch())
        {
	   
?>
<div class="row-fluid center">
       <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Nouveau article</h5>
        </div>

        <div class="widget-content nopadding">
          <form action="#" method="POST" class="form-horizontal">
           
 	   <div class="control-group">
              <label class="control-label">Article :</label>
              <div class="controls">
		<input type="hidden" class="span11" value="<?php echo $resultat["id_sort"];?>" name="id_sorties"/>
                <input type="text" class="span11" value="<?php echo $resultat["article_sort"];?>" name="art"/>
              </div>
		
            </div>
	    <div class="control-group">
              <label class="control-label">Quantité :</label>
              <div class="controls">
                <input type="text" class="span11" value="<?php echo $resultat["qte_sort"];?>" name="qte"/>
              </div>
		
            </div>
	    <div class="controls">
		<span class="red-text"><b><?php
		 if(isset($msg) AND !empty($msg))
                                      {
                                               echo $msg;
                                                   }
                                        ?>
                                                    </b>
                                                </span>
	        </div>
            <div class="form-actions ">
              <span class="pull-right"><button type="submit" class="btn btn-success" name="bt_mdfSort">Valider</button></span>
            </div>
          </form>
        </div>
      </div>
</div>
<?php		
	}
	else{
		echo "Sorties incorrectes; veillez essayer";
	}
}

?>
<?php
break;
case"unite":
?>

<div class="row-fluid center">
       <div class="span6">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>Création d'unité</h5>
        </div>

        <div class="widget-content nopadding">
          <form action="#" method="POST" class="form-horizontal">
              <div class="control-group">
              <label class="control-label">Nouveau unité :</label>
              <div class="controls">
                <input type="text" class="span11"  name="unite_new"/>
              </div>
		
            </div>
	    <div class="controls">
		<span class="red-text"><b><?php

		if(isset($_POST["bt_unite"]) AND !empty($_POST["unite_new"])){
		$unite=$_POST["unite_new"];
		$ret= approControleur::Unite($unite);
		if($ret){
			$msg="*Unitée ajoutée avec succes!";		
		}
		else{
			$msg = "*Une erreur s'est produite, réessayez";
		}
		
		}
		else{
		$msg="Veillez remplir tous les champs!";		
		}

		 if(isset($msg) AND !empty($msg))
                                      {
                                               echo $msg;
                                                   }
                                        ?>
                                                    </b>
                                                </span>
	        </div>
            <div class="form-actions ">
              <span class="pull-right"><button type="submit" class="btn btn-success" name="bt_unite">Enregistrer</button></span>
            </div>
          </form>
        </div>
      </div>
</div>
<?php 

break;
}
}
?>
  
</div>

</div>

<!--end-main-container-part-->

<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2019 &copy;Nicanor Mayumu, Express Technology Lubumbashi</div>
</div>

<!--end-Footer-part-->

<script src="js/excanvas.min.js"></script> 
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flot.min.js"></script> 
<script src="js/jquery.flot.resize.min.js"></script> 
<script src="js/jquery.peity.min.js"></script> 
<script src="js/fullcalendar.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/matrix.dashboard.js"></script> 
<script src="js/jquery.gritter.min.js"></script> 
<script src="js/matrix.interface.js"></script> 
<script src="js/matrix.chat.js"></script> 
<script src="js/jquery.validate.js"></script> 
<script src="js/matrix.form_validation.js"></script> 
<script src="js/jquery.wizard.js"></script> 
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.popover.js"></script> 
<script src="js/jquery.dataTables.min.js"></script> 
<script src="js/matrix.tables.js"></script> 

<script type="text/javascript">
  // This function is called from the pop-up menus to transfer to
  // a different page. Ignore if the value returned is a null string:
  function goPage (newURL) {

      // if url is empty, skip the menu dividers and reset the menu selection to default
      if (newURL != "") {
      
          // if url is "-", it is this page -- reset the menu:
          if (newURL == "-" ) {
              resetMenu();            
          } 
          // else, send page to designated URL            
          else {  
            document.location.href = newURL;
          }
      }
  }

// resets the menu selection upon entry to this page:
function resetMenu() {
   document.gomenu.selector.selectedIndex = 2;
}
</script>
</body>
</html>
