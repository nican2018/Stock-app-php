<?php
    header('location: ../index.php?page=erreur');
?>