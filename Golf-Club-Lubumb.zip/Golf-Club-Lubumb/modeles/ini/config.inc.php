<?php
$host = 'localhost';
$username = 'root';
$password = '';
$bdd_name = 'GolfDB';

