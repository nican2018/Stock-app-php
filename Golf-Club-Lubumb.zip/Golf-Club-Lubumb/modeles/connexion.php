<?php
/**
 * Created by PhpStorm.
 * User: GRAD&MED
 * Date: 17/07/2017
 * Time: 21:28
 */
include(dirname(__FILE__).'/../controleurs/common.php');
class userControler
{
    public function __construct()
    {
    }
    
    public static function Connexion($user,$pass)
    {
        $requette = base()->prepare("SELECT id_user, level FROM user_tab WHERE  username  = ?  AND password =?");
        $requette->bindParam(1, $user,PDO::PARAM_STR);
        $requette->bindParam(2, $pass,PDO::PARAM_STR);
        $requette->execute();
        $requette->bindColumn('id_user',$id);
        $requette->bindColumn('level',$level);
        if($resultat = $requette->fetch(PDO::FETCH_BOUND))
        {
              $_SESSION['level_user']= $level;
              $_SESSION['id_user'] = $id;
	      $_SESSION['user'] = $user;
	      $_SESSION['logged'] = true;
	      return $id;
        }

    }
   
    public static function logoutUser($user)
    {
        session_destroy();
    }
 
    public static function update_pass($pass_user_modifier,$verifier_token)
    {
        $requette = base()->prepare("SELECT mail FROM user_tab WHERE  id_user = ?");
        $requette->bindParam(1, $verifier_token,PDO::PARAM_STR);
        $requette->execute();
        if($resultat = $requette->fetch(PDO::FETCH_BOUND))
        {
            $requette = base()->prepare("UPDATE user_tab SET pass =?  WHERE id_user=? ");
            $requette->bindParam(1, $pass_user_modifier);
            $requette->bindParam(2, $verifier_token);
            $exec = $requette->execute();
            return $exec;
        }
    }
     
}
