<?php
 
include(dirname(__FILE__).'/../controleurs/common.php');
class approControleur
{
    public function __construct()
    {
    }
   public static function Ajout($article, $qte, $date,$unit)
    {
            $requette = base()->prepare("INSERT INTO appro_tab (Designation, qte, unite , date_appro) VALUES (?,?,?,?)");
            $requette->bindParam(1, $article);
            $requette->bindParam(2, $qte);
            $requette->bindParam(3, $unit);
            $requette->bindParam(4, $date);
            return $requette->execute();
    }
 public static function Unite($unite)
    {
            $requette = base()->prepare("INSERT INTO unit_tab (unite_design) VALUES (?)");
            $requette->bindParam(1, $unite);
            return $requette->execute();
    }
 public static function Update($article, $critik)
    {
            $requette = base()->prepare("UPDATE stock  SET pt_critik =? WHERE desig =? ");
	    $requette->bindParam(1,  $critik);
	    $requette->bindParam(2, $article);
	    $exec = $requette->execute();
	    return $exec;
    }
   public static function New($article, $qte, $date)
    {
        $requette = base()->prepare("SELECT id_appro, qte FROM appro_tab WHERE  Designation  = ?");
        $requette->bindParam(1, $article,PDO::PARAM_STR);
        $requette->bindColumn('id_appro',$id);
        $requette->bindColumn('qte',$Old_qte);
	$requette->bindColumn('pt_critic',$crit);
	$requette->bindColumn('date_appro',$date_appro);
	$critic=$crit;
        $requette->execute();

        if(!$resultat = $requette->fetch(PDO::FETCH_BOUND))
        {
            $requette = base()->prepare("INSERT INTO appro_tab (Designation, qte, pt_critic, date_appro) VALUES (?,?,?,?)");
            $requette->bindParam(1, $article);
            $requette->bindParam(2, $qte);
            $requette->bindParam(3, $critic);
            $requette->bindParam(4, $date);
            return $requette->execute();
        }
	else{
	    $new_qte=$Old_qte+$qte;
	    $requette = base()->prepare("UPDATE appro_tab SET qte =?, date_appro =?  WHERE id_appro=? ");
            $requette->bindParam(1, $new_qte);
            $requette->bindParam(2, $date);
            $requette->bindParam(3, $id);
            $exec = $requette->execute();
            return $exec;
	}
    }
  public static function Stock($des, $critik, $qte)
    {
	$requette = base()->prepare("SELECT  id_art, desig, qte, pt_critik FROM stock WHERE  desig  = ?");
        $requette->bindParam(1, $des,PDO::PARAM_STR);
        $requette->bindColumn('id_art',$id);
        $requette->bindColumn('qte',$Old_qte);
	$requette->bindColumn('pt_critic',$crit);
        $requette->execute();

        if(!$resultat = $requette->fetch(PDO::FETCH_BOUND))
        {      
		$requette = base()->prepare("INSERT INTO stock  (desig, qte, pt_critik) VALUES (?,?,?)");
		$requette->bindParam(1, $des);
		$requette->bindParam(2, $qte);
		$requette->bindParam(3, $critik);
		return $requette->execute();
	}
	else{
		    $new_qte=$Old_qte+$qte;
		    $requette = base()->prepare("UPDATE stock  SET qte =? WHERE id_art=? ");
		    $requette->bindParam(1, $new_qte);
		    $requette->bindParam(2, $id);
		    $exec = $requette->execute();
		    return $exec;	
	}	
    }
public static function Sortie($destin, $article, $qte,$unit, $date,$heure)
    {
          
	$requ = base()->prepare("SELECT  id_art, desig, qte, pt_critik FROM stock WHERE  desig  = ?");
        $requ->bindParam(1, $article,PDO::PARAM_STR);
        $requ->bindColumn('id_art',$id);
        $requ->bindColumn('qte',$Old_qte);
	$requ->bindColumn('pt_critik',$pt_critic); 
        $requ->execute();


        if($resultat = $requ->fetch(PDO::FETCH_BOUND))
        {
	
	if($pt_critic<=$Old_qte){
	
	 $requette = base()->prepare("INSERT INTO sortie_tab (destin_sort, article_sort, qte_sort,unite_sort, date_sort, heure_sort) VALUES (?,?,?,?,?,?)");
         $requette->bindParam(1, $destin);
         $requette->bindParam(2, $article);
         $requette->bindParam(3, $qte);
	 $requette->bindParam(4, $unit);
         $requette->bindParam(5,  $date);
	 $requette->bindParam(6,  $heure);
	 $requette->execute();
         $new_qte=$Old_qte-$qte;
	 $req = base()->prepare("UPDATE stock SET qte =?  WHERE id_art=? ");
         $req->bindParam(1, $new_qte);
         $req->bindParam(2, $id);
         return $exec = $req->execute();
	 
	}
    }	 
       
    }

public static function PassUpdate($pswrd,$id)
    {
          
	    $req = base()->prepare("UPDATE user_tab SET password  =?  WHERE id_user=? ");
            $req->bindParam(1, $pswrd);
	    $req->bindParam(2, $id);
            return $exec = $req->execute();	 
       
    }
public static function SuperModif($id, $art, $qte)
    {
          
	$req = base()->prepare("SELECT id_appro,Designation, qte FROM appro_tab WHERE  id_appro  = ?");
        $req->bindParam(1, $id,PDO::PARAM_INT);
        $req->execute();

        if($resultat = $req->fetch())
        {	 
            $req = base()->prepare("UPDATE appro_tab SET Designation  =?, qte=?  WHERE id_appro=? ");
            $req->bindParam(1, $art);
	    $req->bindParam(2, $qte);
	    $req->bindParam(3, $id);
            $exec = $req->execute();

            $reqA = base()->prepare("SELECT id_art, desig, qte FROM stock WHERE  desig  = ?");
            $reqA->bindParam(1, $art,PDO::PARAM_STR);
            $reqA->execute();
            if($res = $reqA->fetch())
            {
      		$new_qte=$res["qte"]-$resultat["qte"]+$qte;
	        $reqE = base()->prepare("UPDATE stock SET qte =?  WHERE desig=? ");
                $reqE->bindParam(1, $new_qte);
                $reqE->bindParam(2, $art);
	        $exec2 = $reqE->execute(); 

		$obj="Entrees";
                $old_qte=$resultat["qte"];
	        $date=date("d/m/Y");

		$reqUp = base()->prepare("INSERT INTO update_tab (objetUp, article_upd, old_qte, new_qte, date_upd) VALUES (?,?,?,?,?)");
               	$reqUp->bindParam(1, $obj);
               	$reqUp->bindParam(2, $art);
		$reqUp->bindParam(3, $old_qte);
		$reqUp->bindParam(4, $qte);
        	$reqUp->bindParam(5, $date);
        	//$exec3 = $reqUp->execute();
                return $reqUp->execute();
                 
            }
   
        }
    }

public static function SuperModifSort($id, $art, $qte)
    {
          
	$req = base()->prepare("SELECT id_sort,destin_sort, article_sort, qte_sort  FROM sortie_tab WHERE  id_sort  = ?");
        $req->bindParam(1, $id,PDO::PARAM_INT);
        $req->execute();

        if($resultat = $req->fetch())
        {	 
            
		$requ = base()->prepare("SELECT  id_art, desig, qte, pt_critik FROM stock WHERE  desig  = ?");
        	$requ->bindParam(1, $art,PDO::PARAM_STR);
               	$requ->bindColumn('qte',$O_qte);
		$requ->bindColumn('pt_critik',$pt_critic); 
        	$requ->execute();


	        if($result = $requ->fetch(PDO::FETCH_BOUND))
        	{
	
			if($pt_critic<=$O_qte){


	    		$req = base()->prepare("UPDATE sortie_tab SET article_sort  =?, qte_sort=?  WHERE id_sort=? ");
            		$req->bindParam(1, $art);
	    		$req->bindParam(2, $qte);
	    		$req->bindParam(3, $id);
           		$exec = $req->execute();  

	    		$reqA = base()->prepare("SELECT id_art, desig, qte FROM stock WHERE  desig  = ?");
            		$reqA->bindParam(1, $art,PDO::PARAM_STR);
            		$reqA->execute();
           		if($res = $reqA->fetch())
           		 {
      				$new_qte=$res["qte"]+$resultat["qte_sort"]-$qte;
	       			$reqE = base()->prepare("UPDATE stock SET qte =?  WHERE desig=? ");
                		$reqE->bindParam(1, $new_qte);
                		$reqE->bindParam(2, $art);
	         
       
                		if($exec2 = $reqE->execute())
               			 {

					$obj="Sortie";
                			$old_qte=$resultat["qte_sort"];
	        			$date=date("d/m/Y");

					$reqUp = base()->prepare("INSERT INTO update_tab (objetUp, article_upd, old_qte, new_qte, date_upd) VALUES (?,?,?,?,?)");
                			$reqUp->bindParam(1, $obj);
                			$reqUp->bindParam(2, $art);
					$reqUp->bindParam(3, $old_qte);
					$reqUp->bindParam(4, $qte);
	        			$reqUp->bindParam(5, $date);
	        			//$exec3 = $reqUp->execute();
	                		return $reqUp->execute();

			
		 		}
          
           		 }
			}
          
           	 }
        }
    }

}
?>
